/* Native interactions. No page-builder or jQuery runtime required. */
(()=>{'use strict';
const ready=()=>{
 document.documentElement.classList.add('native-ready');
 document.querySelectorAll('.layout-invisible').forEach(el=>el.classList.remove('layout-invisible'));
 document.querySelectorAll('.number[data-value]').forEach(el=>{el.textContent=el.dataset.value;});
 document.querySelectorAll('.jkit-accordion .card-wrapper').forEach((card,i)=>{
 const trigger=card.querySelector('.card-header-button'),panel=card.querySelector('.card-expand');if(!trigger||!panel)return;
 panel.id=panel.id||'faq-panel-'+i;trigger.setAttribute('role','button');trigger.setAttribute('aria-controls',panel.id);
 const set=open=>{trigger.setAttribute('aria-expanded',String(open));card.classList.toggle('expand',open);panel.hidden=!open;panel.style.display=open?'block':'none';};
 set(card.classList.contains('expand'));
 trigger.addEventListener('click',e=>{e.preventDefault();set(trigger.getAttribute('aria-expanded')!=='true');});
 trigger.addEventListener('keydown',e=>{if(e.key===' '){e.preventDefault();trigger.click();}});
 });
 document.querySelectorAll('.jkit-nav-menu').forEach((nav,i)=>{
 const button=nav.querySelector('.jkit-hamburger-menu'),panel=nav.querySelector('.jkit-menu-wrapper');if(!button||!panel)return;
 panel.id=panel.id||'native-navigation-'+i;button.setAttribute('aria-controls',panel.id);button.setAttribute('aria-label','メニューを開く');
 let close=panel.querySelector('.jkit-close-menu');if(!close){close=document.createElement('button');close.className='native-menu-close';close.textContent='×';panel.prepend(close);}close.setAttribute('aria-label','メニューを閉じる');
 const set=open=>{nav.classList.toggle('native-menu-open',open);button.setAttribute('aria-expanded',String(open));button.setAttribute('aria-label',open?'メニューを閉じる':'メニューを開く');if(open)close.focus();};
 set(false);button.addEventListener('click',()=>set(button.getAttribute('aria-expanded')!=='true'));close.addEventListener('click',()=>{set(false);button.focus();});
 nav.addEventListener('keydown',e=>{if(e.key==='Escape'){set(false);button.focus();}if(e.key==='Tab'&&nav.classList.contains('native-menu-open')){const items=[...panel.querySelectorAll('a,button')].filter(x=>x.getClientRects().length);const first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
 panel.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>set(false)));
 });
 document.querySelectorAll('.layout-menu-toggle').forEach((toggle,i)=>{
 const parent=toggle.parentElement,panel=parent.querySelector('nav.layout-nav-menu--dropdown');if(!panel)return;panel.id=panel.id||'footer-navigation-'+i;toggle.setAttribute('aria-controls',panel.id);
 const set=open=>{toggle.setAttribute('aria-expanded',String(open));toggle.classList.toggle('layout-active',open);panel.classList.toggle('native-dropdown-open',open);};set(false);
 toggle.addEventListener('click',()=>set(toggle.getAttribute('aria-expanded')!=='true'));toggle.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle.click();}if(e.key==='Escape')set(false);});
 });
 document.querySelectorAll('.testimonials-track').forEach(track=>{
 const slides=[...track.children];if(slides.length<2)return;let current=0;const show=n=>{current=(n+slides.length)%slides.length;slides.forEach((slide,i)=>{slide.hidden=i!==current;});};
 const controls=document.createElement('div');controls.className='native-slider-controls';const previous=document.createElement('button'),next=document.createElement('button');previous.textContent='←';next.textContent='→';previous.setAttribute('aria-label','前の事例');next.setAttribute('aria-label','次の事例');previous.onclick=()=>show(current-1);next.onclick=()=>show(current+1);controls.append(previous,next);track.after(controls);show(0);
 });
};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();

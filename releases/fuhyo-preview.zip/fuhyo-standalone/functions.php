<?php
if (!defined('ABSPATH')) exit;
function fuhyo_manifest() {
 static $data;
 if ($data === null) {
  $file = get_template_directory().'/manifest.json';
  $manifest = is_readable($file) ? json_decode(file_get_contents($file), true) : [];
  $data = is_array($manifest) && isset($manifest['routes']) && is_array($manifest['routes']) ? $manifest['routes'] : [];
 }
 return $data;
}
function fuhyo_route() {
 if (!is_front_page() && !is_page()) return null;
 $path = is_front_page() ? '/' : '/'.trim((string)get_page_uri(get_queried_object_id()),'/').'/';
 foreach (fuhyo_manifest() as $row) if (rawurldecode($row['route']) === rawurldecode($path)) return $row;
 return null;
}
function fuhyo_html($html) {
 return str_replace(['__THEME_URL__','__HOME_URL__'],[esc_url(get_template_directory_uri()),esc_url(untrailingslashit(home_url('/')))],$html);
}
add_filter('the_content', 'fuhyo_html', 20);
add_action('after_setup_theme',function(){add_theme_support('title-tag'); add_theme_support('post-thumbnails');add_theme_support('responsive-embeds');});
add_filter('body_class',function($classes){$r=fuhyo_route();return $r ? array_merge($classes,explode(' ',$r['body_class']??'')) : $classes;});
add_action('wp_enqueue_scripts',function(){
 $r=fuhyo_route();
 foreach (($r['styles']??[]) as $i=>$style) wp_enqueue_style('fuhyo-source-'.$i,get_template_directory_uri().'/'.$style,[],'1.0.0');
 wp_enqueue_style('fuhyo-native',get_template_directory_uri().'/assets/native.css',[],'1.0.0');
 wp_enqueue_script('fuhyo-native',get_template_directory_uri().'/assets/site.js',[],'1.0.0',true);
});
/** Explicit import only. Existing pages are never overwritten. */
function fuhyo_import_pages(){
 if (!current_user_can('manage_options') || !current_user_can('unfiltered_html')) return new WP_Error('forbidden','管理者権限が必要です。');
 $created=[];
 foreach(fuhyo_manifest() as $row){
  $path=trim(rawurldecode($row['route']),'/');
  $path=$path?:'fuhyo-home';
  $parent=0;$segments=explode('/',$path);$slug=array_pop($segments);
  foreach($segments as $segment){
   $parent_path=($parent?get_page_uri($parent).'/':'').$segment;
   $p=get_page_by_path($parent_path);
   if(!$p){$pid=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$segment,'post_name'=>$segment,'post_parent'=>$parent],true);if(is_wp_error($pid))return $pid;$parent=$pid;}else{$parent=$p->ID;}
  }
  $existing=get_page_by_path($path);
  if($existing){$id=$existing->ID;}else{
   $file=get_template_directory().'/'.$row['file'];
   if (!is_readable($file)) return new WP_Error('missing_content','移行元コンテンツがありません。');
   $id=wp_insert_post(wp_slash(['post_type'=>'page','post_status'=>'publish','post_title'=>$row['title'],'post_name'=>$slug,'post_parent'=>$parent,'post_content'=>'<!-- wp:html -->'.file_get_contents($file).'<!-- /wp:html -->']),true);
   if(is_wp_error($id))return $id;$created[]=$id;
  }
  if($row['route']==='/'){update_option('show_on_front','page');update_option('page_on_front',$id);}
 }
 update_option('permalink_structure','/%postname%/');flush_rewrite_rules();return $created;
}
add_action('admin_menu',function(){add_theme_page('再現ページ導入','再現ページ導入','manage_options','fuhyo-import',function(){
 if(!current_user_can('manage_options'))return;
 echo '<div class="wrap"><h1>再現ページを導入</h1><p>8ページを作成してTOPを設定します。既存ページは上書きしません。ブログ・フォーム送信は含みません。</p>';
 if(isset($_POST['fuhyo_import'])){check_admin_referer('fuhyo_import');$r=fuhyo_import_pages();echo '<p>'.esc_html(is_wp_error($r)?$r->get_error_message():count($r).'ページ作成済み').'</p>';}
 echo '<form method="post">';wp_nonce_field('fuhyo_import');submit_button('ページを導入','primary','fuhyo_import');echo '</form></div>';
});});

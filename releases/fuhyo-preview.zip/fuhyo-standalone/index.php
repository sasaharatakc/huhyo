<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<?php if(have_posts()): while(have_posts()): the_post(); the_content(); endwhile; else: ?><main><h1>ページが見つかりません</h1><a href="<?php echo esc_url(home_url('/')); ?>">トップへ</a></main><?php endif; ?>
<?php wp_footer(); ?></body></html>
